/ ** ************************************************ *******
* *
* Javascript para el plugin Title-Footer para Reveal.js *
* *
* Autor: Igor Leturia *
* *
* Licencia: GPL v3 *
* http://www.gnu.org/copyleft/gpl.html *
* *
*************************************************** ***** * /

/ * Objeto de título de página y declaración de propiedades con valores predeterminados * /

var title_footer =
{
	título :  ' ' ,
	fondo : ' rgba (0,0,0,0.1) ' ,
};

/ * Función para obtener todos los elementos secundarios con cualquiera de las etiquetas indicadas (de http://www.quirksmode.org/dom/getElementsByTagNames.html) * /

title_footer . getElementsByTagNames = function ( list , obj )
{
	si ( ! obj)
	{
		var obj = documento ;
	};
	var tagNames = lista . dividir ( ' , ' );
	var resultArray = new  Array ();
	para ( var i = 0 ; i < tagNames . length ; i ++ )
	{
		var etiquetas = obj . getElementsByTagName (tagNames [i]);
		para ( var j = 0 ; j < tags . length ; j ++ )
		{
			resultArray . empujar (etiquetas [j]);
		};
	};
	var testNode = resultArray [ 0 ];
	si ( ! testNode)
	{
		return [];
	};
	if ( testNode . sourceIndex )
	{
		resultArray . tipo (
			función ( a , b )
			{
				devuelve  un . sourceIndex - b . sourceIndex ;
			}
		);
	}
	else  if ( testNode . compareDocumentPosition )
	{
		resultArray . tipo (
			función ( a , b )
			{
				devuelva  3 - ( a . compareDocumentPosition (b) & 6 );
			}
		);
	};
	devuelve resultArray;
};

/ * Método para inicializar el pie de página del Título-pie de página * /

title_footer . inicializar = función ( título , fondo )
{

	// Enlace al CSS de título de pie de página

	var link = documento . createElement ( " link " );
	enlace . href = " plugin / title-footer / title-footer.css " ;
	enlace . type = " text / css " ;
	enlace . rel = " hoja de estilo " ;
	documento . getElementsByTagName ( " head " ) [ 0 ]. appendChild (enlace);

	// Inicializar propiedades de acuerdo a los parámetros.

	esta . fondo = fondo ||  ' rgba (0,0,0,0.1) ' ;
	título var = título ||  ' ' ;
	si (título ! = ' ' )
	{
		esta . título = título;
	}
	más
	{
		var first_section = document . getElementsByTagName ( ' section ' ) [ 0 ];
		if ( first_section . getElementsByTagName ( ' section ' ). length > 0 )
		{
			first_section = first_section . getElementsByTagName ( ' section ' ) [ 0 ];
		};
		var title_elementos = esto . getElementsByTagNames ( ' h1, h2, h3 ' , first_section);
		if ( title_elements . length > 0 )
		{
			esta . title = title_elements [ 0 ]. contenido de texto ;
			para ( var title_elements_index = 1 ; title_elements_index < title_elements . length ; title_elements_index ++ )
			{
				esta . título = este . title + ' - ' + title_elements [title_elements_index]. contenido de texto ;
			};
		};
	};

	// Crear el pie de página del título del pie de página

	var title_footer = documento . createElement ( ' footer ' );
	title_footer . setAttribute ( ' id ' , ' title-footer ' );
	title_footer . setAttribute ( ' style ' , ' background: ' + this . background );
	var title_footer_p = documento . createElement ( ' p ' );
	title_footer . appendChild (title_footer_p);
	var a_element = document . createElement ( ' a ' );
	a_elemento . setAttribute ( ' href ' , ' # / 0 ' );
	a_elemento . appendChild ( document . createTextNode ( this . title ));
	title_footer_p . appendChild (a_element);
	var div_class_reveal = document . querySelectorAll ( ' .reveal ' ) [ 0 ];
	div_class_reveal . appendChild (title_footer);
};

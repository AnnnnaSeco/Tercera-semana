/ ** ************************************************ ****************
** Autor: Asvin Goel, goel@telematique.eu
**
** csv2chart.js es un complemento para reveal.js que permite integrar
** Chart.js en reveal.js
**
** Versión: 0.2
** 
** Licencia: licencia MIT (ver LICENCIA.md)
**
*************************************************** *************** * /

var RevealChart =  ventana . RevealChart  || ( función () {
	función  parseJSON ( str ) {
	    var json;
	    prueba {
        	json =  JSON . parse (str);
	    } atrapar (e) {
        	volver  nula ;
    		}
            devuelve json;
	}

	/ *
	* Combinar recursivamente las propiedades de dos objetos 
	* /
	función  mergeRecursive ( obj1 , obj2 ) {

	  para ( var p en obj2) {
	    prueba {
	      // Propiedad en el conjunto de objetos de destino; actualizar su valor.
	      if (obj1 [p]. constructor == Object  && obj2 [p]. constructor == Object ) {
	        obj1 [p] =  mergeRecursive (obj1 [p], obj2 [p]);
	
	      } else {
	        obj1 [p] = obj2 [p];
	
	      }
	
	    } atrapar (e) {
	      // Propiedad en objeto de destino no establecida; Crealo y establece su valor.
	      obj1 [p] = obj2 [p];
	
	    }
	  }
	
	  devuelve obj1;
	}


	Función  createChart ( lienzo , CSV , comentarios ) {
		lienzo . gráfico  =  nulo ;
		var ctx =  lienzo . getContext ( " 2d " );
		var chartOptions = {responsive :  true };
		var chartData = {labels :  null , datasets : []};
		if (comments ! ==  null ) para ( var j =  0 ; j <  comments . length ; j ++ ) {
			comentarios [j] = comentarios [j]. reemplazar ( / <! - / , ' ' );
			comentarios [j] = comentarios [j]. reemplazar ( / -> / , ' ' );
			var config =  parseJSON (comentarios [j]);
			if (config) {
				if ( config . datos ) {
					mergeRecursive (chartData, config . data );
				}
				si ( config . Opciones ) {
					mergeRecursive (chartOptions, config . options );
				}
			}
		}
		
		var líneas =  CSV . dividir ( ' \ n ' ). filtro ( función ( v ) { return v ! == ' ' });
		// si las etiquetas no están definidas, obténlas desde la primera línea
		if ( chartData . labels  ===  null  &&  lines . length  >  0 ) {
			chartData . etiquetas  = líneas [ 0 ]. dividir ( ' , ' );
			chartData . etiquetas . shift ();
			líneas . shift ();
		} 
		// obtener valores de datos
		para ( var j =  0 ; j <  líneas . longitud ; j ++ ) {
			if ( chartData . datasets . length  <= j) chartData . conjuntos de datos [j] = {};
			chartData . conjuntos de datos [j]. datos  =   líneas [j]. dividir ( ' , ' ); // .filter (función (v) {return v! == ''});
			chartData . conjuntos de datos [j]. label  =  chartData . conjuntos de datos [j]. datos [ 0 ];
			chartData . conjuntos de datos [j]. los datos . shift ();
			para ( var k =  0 ; k <  chartData . datasets [j]. data . length ; k ++ ) {
				chartData . conjuntos de datos [j]. data [k] =  Number ( chartData . datasets [j]. data [k]);
			}
		}

		// añadir opciones de gráfico
		var config = chartConfig [ lienzo . getAttribute ( " tabla de datos " )];
		if (config) {
			para ( var j =  0 ; j <  chartData . datasets . length ; j ++ ) {
				para ( var attrname en config) {
					if ( ! chartData . datasets [j] [attrname]) {
						chartData . conjuntos de datos [j] [attrname] = config [attrname] [j % config [attrname]. longitud ];  
					}
				}
			}
		}		

		lienzo . chart  =  new  Chart (ctx, {type :  canvas . getAttribute ( " data-chart " ), data : chartData, options : chartOptions});

	}

	var  initializeCharts  =  function () {
		// Obtener todos los lienzos
		var lienzos =  documento . querySelectorAll ( " canvas " );
		para ( var i =  0 ; i <  lienzos . longitud ; i ++ ) {
			// comprobar si el lienzo tiene atributo de gráfico de datos
			if (lienzos [i]. hasAttribute ( " data-chart " )) {
				var  CSV  = lonas [i]. innerHTML . recortar ();
				var comentarios =  CSV . coincidencia ( / <! - [ \ s \ S ] *? -> / g );
				CSV  =  CSV . reemplazar ( / <! - [ \ s \ S ] *? -> / g , ' ' ). reemplazar ( / ^ \ s * \ n / gm , " " )
				if ( ! canvases [i]. hasAttribute ( " data-chart-src " )) {
					createChart (lienzos [i], CSV , comentarios);
				}
				else {
					var canvas = lienzos [i];
					var xhr =  nuevo  XMLHttpRequest ();
					xhr . onload  =  function () {
						if ( xhr . readyState  ===  4 ) {
							createChart (canvas, xhr . responseText , comentarios);
						}
						else {
							consola . warn ( ' Error al obtener el archivo '  +  lienzo . getAttribute ( " data-chart-src " ) + " . ReadyState: "  +  xhr . readyState  +  " , Estado: "  +  xhr . status );
						}
					};

					xhr . abierto ( ' GET ' , lienzo . getAttribute ( " data-chart-src " ), false );
					prueba {
						xhr . enviar ();
					}
					atrapar (error) {
						consola . advertir ( ' Error al obtener el archivo '  +  lienzo . getAttribute ( " data-chart-src " ) +  ' . Asegúrese de que la presentación y el archivo estén en un servidor HTTP y que el archivo se encuentre allí. '  + error) ;
					}
				}

			} 
		}
	}

	función  recreateChart ( lienzo ) {
		var config =  lienzo . carta . config ;
		lienzo . carta . destruir ();
		setTimeout ( function () { canvas . chart  =  new  Chart (canvas, config);}, 500 ); // espera la transición de diapositivas
	}

	// verifica si la opción del gráfico está dada o no
	var chartConfig =  Revelar . getConfig (). tabla  || {};

	// establecer las opciones del gráfico global
	var config = chartConfig [ "por defecto " ];
	if (config) {
		mergeRecursive ( Chart . predeterminados , de configuración);
	}		

	Revelar . addEventListener ( ' ready ' , function () {
		initializeCharts ();
		Revelar . addEventListener ( ' slidechanged ' , function () {
			var lienzos =  Revelar . getCurrentSlide (). querySelectorAll ( " canvas [data-chart] " );
			para ( var i =  0 ; i <  lienzos . longitud ; i ++ ) {
				if (lienzos [i]. chart  && lienzos [i]. chart . config . options . animation ) {
					recreateChart (lienzos [i]);
				}
			}
		
		});
	});
}) ();